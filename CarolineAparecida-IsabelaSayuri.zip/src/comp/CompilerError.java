/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package comp;

public class CompilerError extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
