/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

public class TypeBoolean extends Type {

   public TypeBoolean() { 
	   super("boolean"); 
   }


}
