/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

public class TypeString extends Type {
    
    public TypeString() {
        super("string");
    }
  
}