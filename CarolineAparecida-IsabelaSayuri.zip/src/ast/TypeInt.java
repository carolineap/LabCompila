/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

public class TypeInt extends Type {
    
    public TypeInt() {
        super("int");
    }

}