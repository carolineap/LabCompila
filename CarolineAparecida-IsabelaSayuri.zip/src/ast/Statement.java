/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

abstract public class Statement {

	//abstract public void genC(PW pw);

}
