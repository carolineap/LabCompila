/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/

package ast;

public abstract class Member {

	//public abstract Member getName();

}
