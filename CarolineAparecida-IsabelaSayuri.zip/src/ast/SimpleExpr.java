/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

abstract public class SimpleExpr extends Expr {
	
	@Override
	abstract public Type getType();
	
}
