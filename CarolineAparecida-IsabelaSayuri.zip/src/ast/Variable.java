/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;
import lexer.Token;

public class Variable extends Member {

	public Variable(String name, Type type) {
		this.name = name;
		this.type = type;
		this.qualifier = new Qualifier(Token.PUBLIC, null, null);
	}
	
	public Variable(String name, Type type, Qualifier q) {
		this.name = name;
		this.type = type;
		this.qualifier = q;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Type getType() {
		return this.type;
	}
	
	public Qualifier getQualifier() {
		return this.qualifier;
	}

	private Qualifier qualifier;
	private String name;
	private Type type;
	
}
