/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

public abstract class Term extends SumSubExpr {
	abstract public Type getType();
}
