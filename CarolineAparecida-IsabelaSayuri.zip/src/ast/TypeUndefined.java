/* 	Caroline Aparecida de Paula Silva 
 	Isabela Sayuri Matsumoto 		*/
 	
package ast;

public class TypeUndefined extends Type {
     
  public TypeUndefined() { super("undefined"); }
 
   
}
